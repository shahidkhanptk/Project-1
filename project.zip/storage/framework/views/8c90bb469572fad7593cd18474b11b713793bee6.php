

<?php $__env->startSection('branch-content'); ?>

<div class="row m-1">

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.staff.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project-1\resources\views/frontend/staff/expense.blade.php ENDPATH**/ ?>