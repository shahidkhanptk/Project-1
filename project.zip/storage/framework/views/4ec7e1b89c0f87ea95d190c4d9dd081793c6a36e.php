

<?php $__env->startSection('branch-content'); ?>

<select class="form-select" multiple aria-label="multiple select example">
        <option selected>Open this select menu</option>
        <option value="1">One</option>
        <option value="2">Two</option>
        <option value="3">Three</option>
      </select>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project-1\resources\views/frontend/branch/expense.blade.php ENDPATH**/ ?>