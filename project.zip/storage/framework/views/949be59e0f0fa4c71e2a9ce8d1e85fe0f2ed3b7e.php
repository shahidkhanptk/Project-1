

<?php $__env->startSection('branch-content'); ?>

<div class="row m-1">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
        <div class="card-header">
        <h4 class="card-title">Check Expenses</h4>
        </div>
        <div class="card-body">
        <div class="basic-form">
        <form action="" method="POST">
        <?php echo csrf_field(); ?>
                <div class="form-group">
                <select class="form-control" name="branch_id" required>
                <option value="" selected> Select Branch</option>
                <?php $__currentLoopData = $branchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->branch_name); ?></option>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div class="col-xl-12 col-lg-12 mt-3">
                <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        </div>
        </div>
        </div>
        </div>
</div>
<div class="row m-1">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
        <div class="card-header">
        <h4 class="card-title">Check Donation</h4>
        </div>
        <div class="card-body">
        <div class="basic-form">
        <form action="" method="POST">
        <?php echo csrf_field(); ?>
                <div class="form-group">
                <select class="form-control" name="branch_id" required>
                <option value="" selected> Select Branch</option>
                <?php $__currentLoopData = $branchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->branch_name); ?></option>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div class="col-lg-12 mt-3">
                <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        </div>
        </div>
        </div>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project-1\resources\views/frontend/Admin/expense.blade.php ENDPATH**/ ?>