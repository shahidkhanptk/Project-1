
<?php $__env->startSection('branch-content'); ?>
<div class="row m-1">
<div class="col-lg-12">
    <div class="card">
    <div class="card-header">
    <h4 class="card-title">View Account of Branch / Office</h4>
    <div class="col-sm-10">
        <a href="<?php echo e(route('branch.create')); ?>">
        <button type="submit" class="btn btn-primary float-right">Create</button>
        </a>    
    </div>

</div>
    <div class="card-body">
    <div class="table-responsive">
        <table class="table table-responsive-md">
            <thead>
    <tr>
    <th><strong>#id</strong></th>
    <th><strong>Admin</strong></th>
    <th><strong>Email</strong></th>
    <th><strong>Branch Name</strong></th>
    <th><strong>Branch Address</strong></th>
    <th><strong>Dated</strong></th>
    <th><strong>Status</strong></th>
    <th><strong>Action</strong></th>
</tr>
    </thead>
    <tbody>
        
        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
    <tr>
    <td>#<?php echo e($branch->id); ?></td>
    <td><?php echo e($branch->admin->name); ?></td>
    <td><?php echo e($branch->email); ?></td>
    <td><?php echo e($branch->branch_name); ?></td>
    <td><?php echo e($branch->branch_address); ?></td>
    <td><?php echo e($branch->updated_at); ?></td>
    <td><div class="d-flex align-items-center"><i class="fa fa-circle text-success mr-1"></i> Successful</div></td>
    <td>
    <div class="d-flex">
    <a href="<?php echo e(route('branch.edit', $branch->id)); ?>" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></a>
    <a href="<?php echo e(route('branch.delete', $branch->id)); ?>" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
    </div>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
    </table>
    </div>
    </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project-1\resources\views/frontend/branch/list.blade.php ENDPATH**/ ?>