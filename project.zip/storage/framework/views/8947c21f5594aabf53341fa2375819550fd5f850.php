<?php $__env->startSection('home-content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project-1\resources\views/home.blade.php ENDPATH**/ ?>