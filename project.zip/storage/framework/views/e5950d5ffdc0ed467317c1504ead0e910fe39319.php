

<?php $__env->startSection('branch-content'); ?>

<div class="col-xl-6 col-lg-6">
    <div class="card">
    <div class="card-header">
    <h4 class="card-title">Select List</h4>
    </div>
    <div class="card-body">
    <div class="basic-form">
    <form>
    <div class="">
    <label>Select list (select one):</label>
    
    </div>
    </form>
    </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project-1\resources\views/frontend/branch/amount.blade.php ENDPATH**/ ?>