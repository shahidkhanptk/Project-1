@extends('frontend.app')

@section('branch-content')

<select class="form-select" multiple aria-label="multiple select example">
        <option selected>Open this select menu</option>
        <option value="1">One</option>
        <option value="2">Two</option>
        <option value="3">Three</option>
      </select>

@endsection