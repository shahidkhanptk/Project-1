@extends('frontend.staff.app')

@section('branch-content')

<div class="row m-1">

</div>

@endsection