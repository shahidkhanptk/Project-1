@extends('frontend.branch.app')

@section('home-content')

@endsection