@extends('frontend.app')

@section('home-content')

@endsection